<?php

define('COMPANY_NAME', 'Electric scooter inc');
define('PAGE_DEFAULT_TITLE', 'Welcome to ELECTRISCOOTERS.com');
define('WEBSITE_ NAME', 'ElecticScooter.com');
define('COMPANY_PHONE', '55555555555');
define('COMPANY_EMAIL', 'info@abc.com');
define('DESCRIPTION', 'ELECTRISCOOTERS.com has widest range of electric scooterd in montreal');
define('AUTHOR', 'Ranulf Jonathan Noronha');
define('LANG', 'en=CA');
define('ICON', 'image.png');
define('ADMIN_EMAIL', 'admin@abc.com');
